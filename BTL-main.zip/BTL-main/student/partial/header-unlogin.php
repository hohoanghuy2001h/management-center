
<div class="header">
    <div class="container-fluid !direction !spacing">
        <div class="row">
            <div class="col-2 logo">
                <div class="text" onclick="window.location.assign('../home.php');">VASCO</div>
            </div>
            <div class="col-7 search-bar">
                <nav class="navbar" style="width: 100%">
                    <form class="form-inline search-wrapper">
                        <input class="form-control" type="search" placeholder="Tìm kiếm khoá học tại đây" aria-label="Search">
                        <iconify-icon icon="material-symbols:search-rounded"></iconify-icon>
                    </form>
                    </nav>
            </div>
            <div class="col-3 row button-bar">
                <div class="login" onclick="window.location.assign('./login.php');">Đăng nhập</div>
                <div class="signup" onclick="window.location.assign('./register.php');">Đăng ký</div>   
            </div>
        </div>
    </div>
</div>